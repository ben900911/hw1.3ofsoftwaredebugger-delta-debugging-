  <title>Sockets</title>
  <desc>A guide to socket programming with Python.</desc>
  </bookmark>

  <bookmark href="http://www.pythonware.com/library.htm">
  <title>Tkinter guides and documentation</title>
  <desc>An introduction to Tkinter, a class reference and the Tk manual
  pages, all linked to from the Pythonware library page.</desc>
  </bookmark>

  <bookmark href="http://starship.skyport.net/crew/davem/cgifaq/faqw.cgi">
  <title>The Python CGI FAQ</title>
  </bookmark>
  
  <bookmark href="http://www.python.org/topics/">
  <title>Topic Guides &#x04a; python.org</title>
  <desc>This is a collection of topic guides as a part of the Python
  language website. Among the topics are XML, databases, Tkinter and
  web programming.</desc>
  </bookmark>

  <bookmark href="http://www.python.org/doc/howto/">
  <title>HOWTOs @ python.org</title>
  <desc>A collection of HOWTO guides, covering Medusa, Curses, Qt,
  regular expressions and XML, among other things.</desc>
  </bookmark>
  
</folder>

<folder>
<title>Development environments</title>

  <bookmark href="http://www.python.org/emacs/">
  <title>Emacs modes for Python</title>
  <desc>This site contains some useful elisp packages such as a Python mode,
  a debugger mode etc.</desc>
