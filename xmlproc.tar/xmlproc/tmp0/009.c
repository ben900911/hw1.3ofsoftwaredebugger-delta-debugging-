  
  <bookmark href="http://www.python.org/topics/">
  <title>Topic Guides &#x04a; python.org</title>
  <desc>This is a collection of topic guides as a part of the Python
  language website. Among the topics are XML, databases, Tkinter and
