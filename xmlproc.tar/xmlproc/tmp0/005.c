  <title>Sockets</title>
  <desc>A guide to socket programming with Python.</desc>
  </bookmark>

  <bookmark href="http://www.pythonware.com/library.htm">
  <title>Tkinter guides and documentation</title>
  <desc>An introduction to Tkinter, a class reference and the Tk manual
  pages, all linked to from the Pythonware library page.</desc>
  </bookmark>

  <bookmark href="http://starship.skyport.net/crew/davem/cgifaq/faqw.cgi">
  <title>The Python CGI FAQ</title>
  </bookmark>
  
  <bookmark href="http://www.python.org/topics/">
  <title>Topic Guides &#x04a; python.org</title>
  <desc>This is a collection of topic guides as a part of the Python
  language website. Among the topics are XML, databases, Tkinter and
